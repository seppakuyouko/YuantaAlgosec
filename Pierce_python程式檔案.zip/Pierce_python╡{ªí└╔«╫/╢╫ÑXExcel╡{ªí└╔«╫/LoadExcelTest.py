# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 14:19:53 2019

@author: user
"""

import time
import openpyxl #xlsx套件
from openpyxl.styles import Font
#import json 
#import re #正規化
#import requests #api串接
#import pandas
#from pprint import pprint
 
workbook = openpyxl.Workbook()
 
print(workbook.get_sheet_names())
sheet = workbook.active

#字型
#italic24_Font = Font(size=24, italic=True)
#sheet['A1'].font = italic24_Font

#Set Header欄位 
sheet['A1'] = 'From'
#print(sheet['A1'].value)
sheet['B1'] = 'Source'
sheet['C1'] ='Destination'
sheet['D1'] ='Services'
sheet['E1'] ='Action'
sheet['F1'] ='Comment'
sheet['G1'] ='Log'
sheet['H1'] ='Schedule'
#Set Culunm Value
#Set WorkSheetName
sheet.title = 'EXCEL測試'
print(sheet.title)

print(workbook.get_sheet_names())

print(time.time())  #输出的是时间戳

# 保存到文件
workbook.save('ExcelExportTest'+str(time.time())+'.xlsx')