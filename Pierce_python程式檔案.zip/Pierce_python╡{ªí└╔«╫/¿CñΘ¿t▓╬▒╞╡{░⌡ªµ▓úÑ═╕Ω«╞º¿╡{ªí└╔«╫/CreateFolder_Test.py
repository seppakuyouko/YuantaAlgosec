# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 15:03:51 2019

@author: user
"""


import os
import datetime
#import time

#取得目前年度
NowDateTime = datetime.datetime.now() #現在時間
Year = NowDateTime.year
Month = NowDateTime.month

print(Year)
print(Month)



#判斷路徑下是否有當年度資料夾，若無則建立
path = "D:\\Algosec_SystemCreateFolder\\"+str(Year)

FolderPath =path+"\\"+str(Month)
print(path)

print(FolderPath)


if not os.path.isdir(path):
    os.mkdir(path)
    print(path)
    
    if not os.path.isdir(FolderPath):
      os.mkdir(FolderPath)
      print(FolderPath)
#檔案寫入
#file = open(FolderPath+"\\" + "FolderTest.txt", "w")